# CRUD-localStorage
Simple Web Application CRUD with localStorage HTML5.

This is sample web application CRUD with localStorage HTML5.

## credit : 

* Nyekrip - Web Tutorial Indonesia : www.nyekrip.com
* Bootstrap : http://getbootstrap.com

